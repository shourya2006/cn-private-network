"""Run the DNS TTL and cache-flush demonstration from a Mac 1 terminal."""

import argparse
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time


SETUP = Path(__file__).resolve().with_name("setup.py")
NAME = "ttl-demo.team1.test"
PRIMARY = "192.0.2.11"
EDGE = "192.0.2.12"
ALTERNATE = "192.0.2.14"
CACHE_PORT = "1053"


def run(*args):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT).strip()


def query(label, address, port, expected, name=NAME):
    answer = run(
        "dig", f"@{address}", "-p", port, name, "A",
        "+time=2", "+tries=1", "+noall", "+answer",
    )
    print(f"{time.strftime('%H:%M:%S')} {label}: {answer or '(no answer)'}", flush=True)
    records = [line.split() for line in answer.splitlines()]
    if not any(len(r) == 5 and r[0] == name + "." and r[3:] == ["A", expected] for r in records):
        raise RuntimeError(f"Expected {expected} for {label}.")


def set_record(runtime, pid, address, record="ttl-demo"):
    run(sys.executable, str(SETUP), "--runtime", str(runtime), "set-record", record, "--target", address)
    os.kill(pid, signal.SIGHUP)
    time.sleep(0.25)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True, help="Directory of the running Mac 1 dnsmasq")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--cutover", action="store_true", help="Switch the app record to standby and capture cache expiry")
    mode.add_argument("--restore", action="store_true", help="Restore the app record to the primary edge")
    args = parser.parse_args()
    runtime = args.runtime.expanduser().resolve()
    hosts = runtime / "project.hosts"
    pid = int((runtime / "dnsmasq.pid").read_text().strip())
    listener = run("lsof", "-nP", "-a", "-p", str(pid), "-iUDP:53")
    if "dnsmasq" not in listener or f"{PRIMARY}:53" not in listener:
        raise RuntimeError("The recorded primary DNS process does not own the expected socket.")
    os.kill(pid, 0)
    if args.restore:
        set_record(runtime, pid, EDGE, "app")
        query("Restored app authoritative answer", PRIMARY, "53", EDGE, "app.team1.test")
        return
    name = "app.team1.test" if args.cutover else NAME
    record = "app" if args.cutover else "ttl-demo"
    query("Initial authoritative answer", PRIMARY, "53", EDGE, name)
    dnsmasq = Path(run("brew", "--prefix", "dnsmasq")) / "sbin" / "dnsmasq"

    with tempfile.TemporaryDirectory(dir=runtime) as temporary:
        backup = Path(temporary) / "project.hosts"
        shutil.copy2(hosts, backup)
        with tempfile.TemporaryFile(mode="w+t") as log:
            cache = subprocess.Popen(
                [
                    str(dnsmasq), "--no-daemon", "--conf-file=/dev/null",
                    f"--port={CACHE_PORT}", "--listen-address=127.0.0.1",
                    "--bind-interfaces", "--no-hosts", "--no-resolv",
                    f"--server=/{name}/{PRIMARY}#53",
                ],
                stdout=log, stderr=log,
            )
            changed = False
            try:
                time.sleep(0.5)
                if cache.poll() is not None:
                    log.seek(0)
                    raise RuntimeError(log.read().strip() or "The test cache could not start.")
                query("Warm cache", "127.0.0.1", CACHE_PORT, EDGE, name)
                changed = True
                set_record(runtime, pid, ALTERNATE, record)
                query("Changed authoritative answer", PRIMARY, "53", ALTERNATE, name)
                query("Cached old answer before expiry", "127.0.0.1", CACHE_PORT, EDGE, name)
                time.sleep(31)
                query("New answer after TTL expiry", "127.0.0.1", CACHE_PORT, ALTERNATE, name)
                if args.cutover:
                    changed = False
                    print("Primary app DNS now points to standby. Run this script with --restore after the HTTPS check.")
                    return
                set_record(runtime, pid, EDGE)
                query("Restored authoritative answer", PRIMARY, "53", EDGE)
                query("Cached answer before manual flush", "127.0.0.1", CACHE_PORT, ALTERNATE)
                os.kill(cache.pid, signal.SIGHUP)
                time.sleep(0.25)
                query("Fresh answer immediately after manual flush", "127.0.0.1", CACHE_PORT, EDGE)
            finally:
                try:
                    if changed:
                        os.replace(backup, hosts)
                        os.kill(pid, signal.SIGHUP)
                finally:
                    if cache.poll() is None:
                        cache.terminate()
                        cache.wait(timeout=3)
    print("TTL and manual flush verified. The original project records are restored.")


if __name__ == "__main__":
    main()
