# Packet Pioneers CN Phase 2 submission

This GitHub edition uses reserved documentation IPs and substitute Ethernet addresses. It preserves the recorded results, timestamps, ports, frame numbers and protocols. Use host settings from the team for a live run.


Open `CN_Phase2_Final_Report.pdf` for the results, current topology, layered request flow and evaluation plan. Extensions A to E were verified on 23 November 2026. Extension F is the faculty-injected fault to be diagnosed live.

| Item | Location |
|---|---|
| Final report and updated architecture | `CN_Phase2_Final_Report.pdf`, architecture on page 2 |
| Evaluation order and fault diagnosis | `Live_Demo.md` |
| Deployment and recovery | `config/README.md` |
| Primary and standby nginx, DNS, TLS and temporary PF settings | `config/` |
| Pinned application source for both backends | `backend/app.py` |
| Phase 2 outputs and test records | `evidence/INDEX.md` |
| Phase 1 project capture and frame index | `evidence/phase1/mac3-project-flow.pcap` and `evidence/phase1/Frame_Index.md` |
| Phase 1 source instructions and earlier runbooks | `reference/` |

The Phase 1 nginx configuration is a reconstruction of the documented setup. The live Phase 2 nginx files come from Macs 2 and 4. The traffic capture contains the project DNS and HTTPS flow from Mac 3. Use the new frame numbers in its index.

Repository and source commit

https://github.com/shourya2006/cn-private-network/tree/47fcea0f000ea8bfc64db60f2442dc04b05096ef
