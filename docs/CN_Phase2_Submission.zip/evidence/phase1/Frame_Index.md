# Phase 1 project flow in Wireshark

This GitHub edition uses reserved documentation IPs and substitute Ethernet addresses. It preserves the recorded results, timestamps, ports, frame numbers and protocols. Use host settings from the team for a live run.


Use `mac3-project-flow.pcap`. The 30 retained frames contain the original project DNS query and the TCP stream tied to the captured request on 5 October 2026. Filtering preserved packet timing and produced new display frame numbers.

| Layer | Filter or frames | What to show |
|---|---|---|
| DNS | `dns`, frames 1 and 2 | Mac 3 asked for the app A record and Mac 1 replied with the October edge IP 198.51.100.12. |
| TCP | `tcp.port == 8443`, frames 3 to 5 | SYN, SYN-ACK and ACK. Client used port 53453. |
| TLS 1.2 | `tls`, frames 6 and 9 | ClientHello with app hostname as SNI, then ServerHello and Certificate. |
| TLS 1.2 | Frames 11 and 13 | ChangeCipherSpec on both sides. |
| HTTPS | Frames 15 and 17 | Encrypted application data. The matching `mac3-flow-curl.txt` shows certificate verification and HTTP 200. |

These October addresses are historical. Use the November addresses in the final report to demonstrate the current configuration.
