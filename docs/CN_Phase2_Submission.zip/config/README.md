# Configuration and recovery

This GitHub edition uses reserved documentation IPs and substitute Ethernet addresses. It preserves the recorded results, timestamps, ports, frame numbers and protocols. Use host settings from the team for a live run.


The addresses reflect the 23 November 2026 lab tests. Verify IPv4 addresses and interfaces on the four Macs before replaying the demonstration. Keep this bundle with the team and evaluator.

## DNS on Macs 1 and 4

Run from the unzipped submission directory on each DNS host. Use the matching listen IP and a separate local runtime directory on each Mac.

| DNS role | Mac | Listen IPv4 | Baseline edge IPv4 |
|---|---|---|---|
| Primary | 1 | 192.0.2.11 | 192.0.2.12 |
| Backup | 4 | 192.0.2.14 | 192.0.2.12 |

```bash
python3 config/dns/setup.py --runtime "$PWD/runtime/phase2-dns" prepare \
  --listen-ip YOUR_DNS_IP --edge-ip 192.0.2.12
```

The helper writes dnsmasq settings, a PID-file path and project host records. It preserves an existing hosts file. Compare that file to `config/dns/project.hosts` before the demo. The prepared server listens on UDP/TCP 53 and advertises a 30-second TTL for the private records. See the DNS runbook in `reference/` for syntax and listener checks, the project-only macOS resolver, process identity checks and rollback. The example resolver records the observed Mac 2 DNS order. Prefer the normal scoped lookup when testing application behavior and use explicit resolver queries when comparing server answers.

Mac 4 supplied an archived dnsmasq config with a static 60-second host-record option. The actual 23 November queries show 30 seconds for app and api. Use the fresh helper-generated configuration above to reproduce the measured TTL. The Mac 4 cutover and rollback hosts files were staged and the measured cutover changed only Mac 1.

The archived DNS copies preserve the host settings. Use the setup helper to generate paths for a different checkout. On Mac 1, `config/dns/test_ttl.py --runtime PATH` replays Extension B with a loopback-only cache. The script expects the recorded lab IPs. With `--cutover` it leaves the app answer on standby for the HTTPS check. Run it with `--restore` immediately after the check to return the primary app answer to Mac 2. Start with no other changes pending on the test records.

## Backends on Macs 3 and 4

From the submission folder run the applicable command in a service terminal.

```bash
# Mac 3
python3 -u backend/app.py --name A --port 3001
# Mac 4
python3 -u backend/app.py --name B --port 3002
```

Verify the localhost `/api/status` endpoint on each backend. The pinned source is from commit `47fcea0f000ea8bfc64db60f2442dc04b05096ef` in the team repository. Both backends run the same script with a different role and port.

## nginx and TLS on Macs 2 and 4

The Phase 1 implementation plan in `reference/` documents the tested design, including the HTTP redirect, certificate setup and upstream defaults. The normal edge is Mac 2. `nginx/mac2-primary-phase2.conf` and `nginx/mac4-standby-phase2.conf` are the host copies. The original Phase 1 nginx file was lost during a reformat. `nginx/phase1-reconstructed.conf.example` follows the checked-in Phase 1 setup and needs path and IP substitution. The standby edge on Mac 4 was used for the controlled migration. Each Mac's nginx needs its own live key path and matching certificate file. Validate syntax on the edge host before loading a configuration. Keep the private keys on their respective hosts.

`tls/phase1-primary-expired.crt` is the public certificate from the Phase 1 repository and expired on 4 November 2026. For live primary-edge tests use `tls/primary-server.crt`, supplied by Om for Phase 2. The active primary and standby public certificates were issued separately and both expire on 23 December 2026. `tls/standby-server.crt` is the public certificate presented by Mac 4 during the cutover. Use the matching certificate in each HTTPS check. Both certificates identify `app.team1.test` and `api.team1.test` in their SANs. Compare a supplied certificate's SHA-256 fingerprint with the owning edge before relying on it, and use a verified `curl --cacert` request with the application hostname.

## Temporary PF test and rollback

The two `.pf` files contain the isolated rules used in Extension C. The test anchors were `com.apple/cn-phase2-a` and `com.apple/cn-phase2-b`. Reuse only on the corresponding project Mac after checking the interface, IP, active parent anchor and empty test anchor. See `../evidence/extension-c-firewall-isolation.txt` for the tested time windows and rollback confirmations. The end-of-test state was an empty test anchor on each Mac and a healthy local backend. Retain the existing host PF policy. Roll back only the test anchor used for the demo.
