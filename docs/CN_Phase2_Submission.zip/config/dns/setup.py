"""Prepare dnsmasq files for the Phase 2 project LAN."""

import argparse
import ipaddress
import os
from pathlib import Path
import tempfile


ZONE = "team1.test"
DEFAULT_RUNTIME = Path("runtime/phase2-dns")
RECORDS = ("app", "api", "ttl-demo")


def ipv4(value):
    try:
        address = ipaddress.IPv4Address(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error)) from error
    if address.is_unspecified or address.is_multicast or address.is_reserved:
        raise argparse.ArgumentTypeError("Enter a unicast IPv4 address.")
    return str(address)


def port_number(value):
    port = int(value)
    if not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError("Enter a port from 1 to 65535.")
    return port


def write_atomic(path, content):
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, delete=False
    ) as output:
        temporary = Path(output.name)
        try:
            output.write(content)
            output.flush()
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)


def record_line(name, address):
    return f"{address} {name}.{ZONE}\n"


def prepare(args, runtime):
    conf = runtime / "dnsmasq.conf"
    hosts = runtime / "project.hosts"
    pid = runtime / "dnsmasq.pid"
    settings = [
        f"port={args.port}",
        f"listen-address={args.listen_ip}",
        "bind-interfaces",
        "no-hosts",
        "no-resolv",
        f"local=/{ZONE}/",
        "local-ttl=30",
        f'addn-hosts="{hosts}"',
        f'pid-file="{pid}"',
    ]
    if args.upstream:
        settings.append(f"server={args.upstream}")
    if any(character in str(runtime) for character in ('"', "\\", "\n", "\r")):
        raise ValueError("Use a runtime directory without quotes, backslashes or newlines.")
    runtime.mkdir(parents=True, exist_ok=True)
    if not hosts.exists():
        write_atomic(hosts, "".join(record_line(name, args.edge_ip) for name in RECORDS))
    write_atomic(conf, "\n".join(settings) + "\n")
    print(f"Configuration: {conf}\nRecords: {hosts}\nPID file: {pid}")


def set_record(args, runtime):
    hosts = runtime / "project.hosts"
    lines = hosts.read_text(encoding="ascii").splitlines(keepends=True)
    name = f"{args.record}.{ZONE}"
    matches = [index for index, line in enumerate(lines) if line.split()[1:] == [name]]
    if len(matches) != 1:
        raise ValueError(f"Expected one {name} entry in {hosts}.")
    lines[matches[0]] = record_line(args.record, args.target)
    write_atomic(hosts, "".join(lines))
    print(f"{name} -> {args.target}")
    print("Reload the running project dnsmasq to serve the updated record.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, default=DEFAULT_RUNTIME)
    commands = parser.add_subparsers(dest="command", required=True)
    setup = commands.add_parser("prepare", help="Prepare this Mac's DNS files")
    setup.add_argument("--listen-ip", type=ipv4, required=True)
    setup.add_argument("--edge-ip", type=ipv4, required=True)
    setup.add_argument("--upstream", type=ipv4)
    setup.add_argument("--port", type=port_number, default=53)
    setup.set_defaults(run=prepare)
    edit = commands.add_parser("set-record", help="Change one managed DNS record")
    edit.add_argument("record", choices=RECORDS)
    edit.add_argument("--target", type=ipv4, required=True)
    edit.set_defaults(run=set_record)
    args = parser.parse_args()
    try:
        if args.command == "prepare" and args.upstream == args.listen_ip:
            raise ValueError("The upstream DNS address must differ from the listen address.")
        args.run(args, args.runtime.expanduser().resolve())
    except (OSError, ValueError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()
