# Phase 2 live demonstration

Before the slot, confirm the current IPv4 addresses, both DNS listeners, the primary edge certificate and both backend processes. Keep a clean project-only packet capture open in Wireshark. Run any fault or cutover only in the agreed test window and restore it before moving on.

| Step | Lead | Demonstration and expected observation |
|---|---|---|
| 1 | Shourya | Open the architecture page of the report. Show the four machines, network addresses and service ports. |
| 2 | All | Confirm the Macs are on the same private LAN. Show current IPv4 addresses and run the evaluator's directed peer pings. Record fresh results if DHCP addresses changed. |
| 3 | Shourya | Query the app A record. Show both project resolvers and identify the baseline Mac 2 answer. On macOS use the scoped resolver view and a normal system lookup alongside direct DNS probes. |
| 4 | Om | Open `https://app.team1.test:8443/api/status` using the current trusted certificate. Show HTTP 200 and the backend identity. |
| 5 | Om | Repeat the HTTPS request. Show both A and B in `X-Backend` response headers. |
| 6 | Daksh | Open the saved Phase 1 project flow in Wireshark. Point out the DNS query and answer, SYN/SYN-ACK/ACK, and TLS ClientHello/ServerHello. Use the frame numbers in `evidence/phase1/Frame_Index.md` for the supplied filtered capture. |
| 7 | Daksh | Request headers for `/cache`, then repeat with the returned ETag in `If-None-Match`. Show the matching request returns HTTP 304. |
| 8 | Daksh, Om | Stop A for the test. Show only B returning HTTP 200 through nginx. Restart A and show both backends serving again. |
| 9 | Shourya, Aditya | Demonstrate DNS fallback, TTL expiry or controlled cutover as requested. During cutover record the old cached answer, the new answer, the validated standby response and the restored primary record. Show the Extension C evidence if asked. |
| 10 | All | Diagnose the fault injected by faculty. Follow DNS, TCP, TLS and HTTP in order and report the first failing layer. Verify the repair using the original request. |
| 11 | All | Explain your component and how it connects to the rest of the system in the individual viva. |

## Fault isolation

| Layer | What to check | Interpretation |
|---|---|---|
| DNS | Compare expected A records from the two resolvers and via the normal client lookup. | A direct answer with a stale normal answer points to resolver routing or cache state. |
| TCP | Check client-to-edge TCP 8443 and authorized edge-to-backend connectivity to 3001 and 3002. | A correct DNS answer with no TCP connection points to reachability, a listener or a filter. |
| TLS | Check the certificate chain, date and SAN against the requested hostname and confirm SNI. | A working TCP path can still have a certificate or TLS configuration fault. |
| HTTP | Compare `/edge-health`, `/api/status`, `X-Backend` and the nginx upstream log. | Edge health with upstream errors narrows the fault to proxy routing or backend service. |
