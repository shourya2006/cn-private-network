# Evidence index

This GitHub edition uses reserved documentation IPs and substitute Ethernet addresses. It preserves the recorded results, timestamps, ports, frame numbers and protocols. Use host settings from the team for a live run.


November test times are IST. October artifacts document the Phase 1 baseline and use the addresses from that session.

| Test | Evidence | Observation |
|---|---|---|
| A — DNS failover | `mac2/dns-failover.txt` | Primary timed out, backup served a 30-second answer, normal HTTPS returned 200 and primary DNS recovered. |
| B — DNS TTL and cache flush | `extension-b-dns-ttl.txt` | Old answer until expiry, new answer after 31 seconds, immediate update after manual flush. |
| C — Backend firewall | `extension-c-firewall-isolation.txt`, `mac3/backend-a-firewall.txt`, `mac4/backend-b-firewall.txt` | Om reached both backends. Peer requests timed out and both test anchors were cleared. |
| D — Upstream failover | `mac2/failover-1-before.txt`, `mac2/failover-2-during.txt`, `mac2/failover-3-recovery.txt` | Eighteen HTTPS 200 responses, with B handling all six requests during the A outage. |
| E — Standby cutover | `extension-e-dns-cutover.txt`, `mac4/standby-https.txt`, `mac4/backup-dns.txt` | The primary DNS answer switched to the standby after cache expiry. Standby HTTPS returned 200 and the original record was restored. |
| F — Faculty troubleshooting | `../Live_Demo.md` | Live evaluation step. |
| DNS, TCP and TLS packet proof | `phase1/mac3-project-flow.pcap`, `phase1/Frame_Index.md`, `phase1/mac3-flow-curl.txt` | Original project flow retained from Mac 3 with unrelated DNS traffic excluded. |
| HTTPS, balancing and caching | `phase1/`, `mac2/edge-check.txt`, `mac2/http-caching.txt` | Trusted HTTPS, A/B routing and HTTP 304 through nginx with a matching ETag. |

The original Phase 1 archive retained here covers DNS, HTTPS, balancing, caching, the captured flow and the earlier Backend A stop/restart checks. The rest of the Phase 1 failure variants and directed ping matrix are described in the Phase 1 runbook.
