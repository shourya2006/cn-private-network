# Phase 2 DNS and cutover runbook

Run the commands from the submission folder. The dual-resolver cutover below is a replay option. The recorded Extension E test cut over only the primary resolver.

Mac 1 (Shourya) serves primary DNS and Mac 4 (Aditya) serves backup DNS. Both answer for `app.team1.test`, `api.team1.test`, and a separate `ttl-demo.team1.test` record. The app and API normally point to Mac 2 (Om). Mac 4's temporary standby nginx can take over the app name in the cutover demo. Backend A stays on Mac 3 (Daksh) and Backend B on Mac 4.

## Prepare both DNS servers

1. Work from the Phase 1 repo root with this bundle extracted into it. Confirm the current LAN IPv4 of each Mac and fill in `DNS_IP` with your own address and `EDGE_IP` with Mac 2's address.
2. On each DNS Mac, point `DNSMASQ` at your installed dnsmasq. If it is absent, install it using `brew install dnsmasq`. Save the existing project DNS configuration, launch command, and client DNS settings.
3. Generate and validate the Phase 2 configuration. With no `--upstream` option this config serves project DNS only. If your clients need ordinary DNS over the same network settings, add `--upstream <approved-resolver-IP>` on both Macs, using a resolver outside this DNS pair. Use the project config only on the team LAN.

```sh
DNSMASQ="$(brew --prefix dnsmasq)/sbin/dnsmasq"
python3 config/dns/setup.py prepare --listen-ip "$DNS_IP" --edge-ip "$EDGE_IP"
"$DNSMASQ" --test --conf-file="$PWD/runtime/phase2-dns/dnsmasq.conf"
lsof -nP -iUDP:53 -iTCP:53
```

If Phase 1 dnsmasq already owns port 53, stop it with its original launch method before starting the Phase 2 instance. Keep the launch terminal open. The user and group options let dnsmasq reread the records in your own checkout after dropping its startup privileges.

```sh
sudo "$DNSMASQ" --keep-in-foreground --user="$(id -un)" --group="$(id -gn)" \
  --conf-file="$PWD/runtime/phase2-dns/dnsmasq.conf"
```

On a client, set `PRIMARY_IP` and `BACKUP_IP` to the current IPv4 addresses of Macs 1 and 4. Confirm both names return Mac 2's IP with TTL 30 from both DNS servers:

```sh
for server in "$PRIMARY_IP" "$BACKUP_IP"; do
  for host in app.team1.test api.team1.test; do
    dig @"$server" "$host" A +time=2 +tries=1 +noall +answer +stats
  done
done
```

Record each client's original `networksetup -getdnsservers "<network service>"` output. In that service's DNS settings, list Mac 1 first and Mac 4 second. Use the same trusted HTTPS URL and certificate check from Phase 1.

## A. Demonstrate fallback to Mac 4

1. Save the healthy lookups and a validated HTTPS request from a client. On that client, start a DNS capture limited to the two project resolvers.
2. Stop the Mac 1 foreground process with Control-C. Check that Mac 1 times out with a direct `dig` query and that Mac 4 still responds.
3. Clear the client DNS cache, then use `dscacheutil -q host -a name app.team1.test` and the regular named HTTPS URL. Save the DNS response from Mac 4 in the client capture and the HTTPS result. This confirms client fallback as well as direct backup availability.
4. Restart Mac 1 using the same command and verify both resolvers again.

On macOS, the cache flush used in the demo is `sudo dscacheutil -flushcache` followed by `sudo killall -HUP mDNSResponder`.

## B. Demonstrate DNS TTL and manual flush

Use `ttl-demo.team1.test` so the app stays on Mac 2 during this experiment. Decide on a second team IP and set `OTHER_IP` to that value on both resolvers. Prime the client's cache while the record still points to Mac 2. On each DNS Mac, change just that record and signal the project dnsmasq:

```sh
python3 config/dns/setup.py set-record ttl-demo --target "$OTHER_IP"
pid="$(cat runtime/phase2-dns/dnsmasq.pid)"
ps -p "$pid" -o command=
# After verifying this PID is the Phase 2 dnsmasq:
kill -HUP "$pid"
```

Capture the old client answer before expiry, a fresh direct DNS answer showing the new IP, then the client answer after 30 seconds. For a second trial, prime the cache again, make another record change on both resolvers, and capture the new client answer immediately after a manual flush. Use `dig @<resolver>` for direct server observations and macOS system lookups for cached client observations.

If the system cache obscures the TTL countdown, use a separate caching dnsmasq on the client, bound to loopback on port 1053. Start it in a separate terminal and query it with `dig @127.0.0.1 -p 1053 ttl-demo.team1.test A +noall +answer`. Stop the client instance with Control-C when done.

```sh
"$DNSMASQ" --no-daemon --conf-file=/dev/null --port=1053 \
  --listen-address=127.0.0.1 --bind-interfaces --no-resolv --no-hosts \
  --server="/team1.test/$PRIMARY_IP"
```

Repeat the update procedure on both DNS Macs with `--target "$EDGE_IP"` to restore the TTL demo record.

## E. Coordinate the app DNS cutover

1. Ask Om and Aditya to confirm the standby on Mac 4 can reach the backends after the Mac 2-only isolation demonstration. Verify certificate-checked HTTPS to the standby ahead of cutover using the app hostname and curl's `--resolve` option.
2. Prime one client's cache for `app.team1.test` while it points to Mac 2. On both DNS Macs run `python3 config/dns/setup.py set-record app --target "$BACKUP_IP"` and reload the verified Phase 2 process using the same steps as above.
3. Compare the cached client's old edge address with a fresh lookup's new address. Use curl's `%{remote_ip}` and `%{http_code}` output to show which edge responds while verifying TLS for the same hostname. Use separate curl processes so an existing connection cannot hide the switch.
4. Restore `app` to `"$EDGE_IP"` on both DNS Macs, reload both, and verify that the ordinary app URL returns through Mac 2. Remove any temporary firewall permissions used during the cutover.

## Evidence and rollback

Save timestamped lookup outputs, the client DNS capture, and validated HTTPS results in the team's private evidence folder. Record the observed TTL, response resolver and edge, and any failed checks for the final report. When the demo is over, restore the saved DNS settings on each client. Stop the Phase 2 instances and restore the Phase 1 service if the team needs it again.
